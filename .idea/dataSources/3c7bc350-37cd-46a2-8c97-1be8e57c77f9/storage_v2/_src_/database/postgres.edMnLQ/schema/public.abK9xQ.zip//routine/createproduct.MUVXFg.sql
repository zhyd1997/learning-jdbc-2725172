create function createproduct(product_name character varying, product_price numeric, vendor_name character varying) returns uuid
    language plpgsql
as
$$
DECLARE
  prod_id UUID;
BEGIN
  prod_id := gen_random_uuid();
  INSERT INTO wisdom.products (product_id, name, price, vendor_id)
  values(
    prod_id, 
    product_name, 
    product_price, 
    (select vendor_id from wisdom.vendors where UPPER(name) = UPPER(vendor_name))
  );
  return prod_id;
END;
$$;

alter function createproduct(varchar, numeric, varchar) owner to postgres;

grant execute on function createproduct(varchar, numeric, varchar) to anon;

grant execute on function createproduct(varchar, numeric, varchar) to authenticated;

grant execute on function createproduct(varchar, numeric, varchar) to service_role;

